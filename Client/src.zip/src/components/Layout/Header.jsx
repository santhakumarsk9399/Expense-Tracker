import React, { useState } from "react";
import "../Css/layout.css";

const Header = ({ toggleSidebar, user, onLogout }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  return (
    <div className="header">
      <div className="left">
        {/* <button onClick={toggleSidebar} className="menu-btn">
          ☰
        </button> */}
        <h2>Expense Tracker</h2>
      </div>

      <div className="right">
        <div className="profile" onClick={() => setShowDropdown(!showDropdown)}>
          <img
            src="https://i.pravatar.cc/40"
            alt="user"
            className="avatar"
          />
          <span>{user?.name}</span>
        </div>

        {showDropdown && (
          <div className="dropdown">
            <p onClick={onLogout}>Logout</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;