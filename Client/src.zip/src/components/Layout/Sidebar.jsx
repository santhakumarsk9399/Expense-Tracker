import React from "react";
import { NavLink } from "react-router-dom";
import "../Css/layout.css";

const Sidebar = ({ isOpen, toggleSidebar, userRole }) => {
    const menu = [
        { name: "Dashboard", path: "/dashboard", roles: ["Admin", "User"] },
        { name: "Expenses", path: "/expenses", roles: ["Admin", "User"] },
        { name: "Users", path: "/users", roles: ["Admin"] },
        { name: "Profile", path: "/profile", roles: ["Admin", "User"] }
    ];

    return (
        <div className={`sidebar ${isOpen ? "open" : "collapsed"}`}>
            <div className="sidebar-header">
                <h3>{isOpen ? "💰 Tracker" : "💰"}</h3>
            </div>

            <ul className="menu">
                {menu
                    .filter((item) => item.roles.includes(userRole))
                    .map((item, index) => (
                        <li key={index}>
                            <NavLink
                                to={item.path}
                                className={({ isActive }) =>
                                    isActive ? "active-link" : ""
                                }
                            >
                                {item.name}
                            </NavLink>
                        </li>
                    ))}
            </ul>

            <button className="toggle-btn" onClick={toggleSidebar}>
                {isOpen ? "⬅" : "➡"}
            </button>
        </div>
    );
};

export default Sidebar;