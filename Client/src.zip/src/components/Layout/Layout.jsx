import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import "../Css/layout.css";

const Layout = ({ children }) => {
    const [isOpen, setIsOpen] = useState(true);

    const user = {
        name: "Santha",
        role: "Admin"
    };

    const toggleSidebar = () => {
        setIsOpen(!isOpen);
    };

    const handleLogout = () => {
        sessionStorage.clear();
        window.location.href = "/login";
    };

    return (
        <div className="layout">
            <Sidebar
                isOpen={isOpen}
                toggleSidebar={toggleSidebar}
                userRole={user.role}
            />

            <div className="main">
                <Header
                    toggleSidebar={toggleSidebar}
                    user={user}
                    onLogout={handleLogout}
                />

                <div className="content">{children}</div>
            </div>
        </div>
    );
};

export default Layout;