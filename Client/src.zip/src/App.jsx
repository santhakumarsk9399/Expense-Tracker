// App.js
import { BrowserRouter, Routes, Route } from "react-router-dom";
// import Layout from "./components/Layout/Layout";
import Dashboard from "./Pages/Dashboard/Dashboard";
import Expenses from "./Pages/Expenses/Expenses";
// import Reports from "./pages/Reports";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/expenses" element={<Expenses />} />
        </Routes>
      </BrowserRouter>


    </>
  );
}

export default App;